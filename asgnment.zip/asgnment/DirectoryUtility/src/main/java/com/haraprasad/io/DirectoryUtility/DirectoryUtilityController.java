package com.haraprasad.io.DirectoryUtility;

/**
* This is Controller class with access to Service that
* returns JSON String containing the lists of files and Dir and Size 
*
* @author  Haraprasad Senapati
* @version 1.0
* @since   2020-07-11 
*/

import java.util.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

@SuppressWarnings("unchecked")
@RestController
@RequestMapping("dir")
public class DirectoryUtilityController {


  @Autowired
  private DirectoryFileUtilityService dirFileUtilService;

  /**
  * This returns JSON String containing the lists of files and Dir and Size 
  *
  * @param   pathName A pathName as one input parameter
  * @return  A formatted JSON String with list of files and dir as output parameter
  */

  @GetMapping("/listing")
  @ResponseBody
  public String getAllFileDirsListForAPath(@RequestParam("pathName") String pathName) throws IOException {

    return dirFileUtilService.getAllFileDirsListForAPathService(pathName);

  } 

  /**
  * This returns JSON String containing attributes of a input file. 
  *
  * @param   fileName A fileName as one input parameter
  * @return  A formatted JSON String with attributes of a file.
  */

  @GetMapping("/fileinfo")
  @ResponseBody
  public String getAttributesForAFile(@RequestParam("fileName") File fileName) throws IOException {

    return dirFileUtilService.getAttributesForAFileService(fileName);

  }

}
