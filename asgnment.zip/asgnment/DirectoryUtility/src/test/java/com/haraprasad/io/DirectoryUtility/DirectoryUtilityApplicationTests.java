package com.haraprasad.io.DirectoryUtility;

import java.util.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.Before;
import org.junit.After;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.Assert.*;

/* 
 Note : You need to do UT for the DirectoryUtilityService.java for both the methods
        first hardcode dir. name and file name DO UT then apply the same to Service class
        Do it later. Nothing impossible.
*/
@SpringBootTest
class DirectoryUtilityApplicationTests {

  private String DOC_DIR  = System.getProperty("user.home")+File.separator+"Documents";
  private String DOC_FILE = System.getProperty("user.home")+File.separator+"Documents"+File.separator+"testFile.txt";

  @Before
    public void init() {
       System.out.println("This is Before....");
  }

  @Test
  public void testJustIf() {
    System.out.println("This is testJustIf....");
  }

  @Test
  public void testIfDocumentDirExists() {
    Path path = Paths.get(DOC_DIR);

    assertTrue(Files.exists(path));
  }

  @Test
  public void testIfDocumentDirDoesNotExists() {
    Path path = Paths.get(DOC_DIR);

    assertFalse(Files.notExists(path));
  }

  @Test
  public void testIfDocumentDirIsARegularFile() {
    Path path = Paths.get(DOC_DIR);

    assertFalse(Files.isRegularFile(path));
  }

  @Test
  public void testIfFileIsARegularFile() {
    Path path = Paths.get(DOC_FILE);

    assertTrue(Files.isRegularFile(path));
  }

  @Test
  public void testIfFileIsAReadable() {
    Path path = Paths.get(DOC_FILE);

    assertTrue(Files.isReadable(path));
  }
  @Test
  public void testIfFileIsWritable() {
    Path path = Paths.get(DOC_FILE);

    assertTrue(Files.isWritable(path));
  }
  @Test
  public void testIfFileIsExecutable() {
    Path path = Paths.get(DOC_FILE);

    assertFalse(Files.isExecutable(path));
  }
  @After
  public void deinit() {
    System.out.println("This is Before....");
  }

}
