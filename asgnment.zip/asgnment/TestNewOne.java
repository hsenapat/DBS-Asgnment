import java.util.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;
import java.util.stream.Collectors;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@SuppressWarnings("unchecked")
public class TestNewOne {

    public static String getAllFileDirsListForAPath(String pathName) throws IOException {

    if (null==pathName || !(pathName.length()>0) ) {
        System.out.println("Pathname is null or the length is not > 0");
        return null;
    }

    List<String> fileDirlist              = null;
    List<String> formattedStr             = null;
    JSONArray    dirFileListJSONArray     = null;

    try (Stream<Path> paths = Files.walk(Paths.get(pathName))) {
            fileDirlist = paths
                .map(path -> Files.isDirectory(path) ? ( path.toString() + '/' ) : path.toString())
                .collect(Collectors.toList());
            System.out.println("---------------------------------------------");
    }
    formattedStr = new ArrayList<String>();
    dirFileListJSONArray = new JSONArray(); 
    try {
    for(String s : fileDirlist) {
        Path path = Paths.get(s);
        
        JSONObject pObj = new JSONObject(); 
        if (Files.isDirectory(path)) {
          pObj.put("Path", path.toString());
          pObj.put("Directory","Yes");
          pObj.put("Size",Files.size(path));
        }else {
          pObj.put("Path", path.toString());
          pObj.put("File","Yes");
          pObj.put("Size",Files.size(path));
        }
        System.out.println(pObj.toString());
        dirFileListJSONArray.add(pObj);
       }
    } catch(Exception exp) {
         System.out.println(exp);
         exp.printStackTrace();
    }

    System.out.println("---------------------------------------------");
    System.out.println(dirFileListJSONArray.toString());
    System.out.println("---------------------------------------------");

    System.out.println("Is : " + dirFileListJSONArray.toString());

    return dirFileListJSONArray.toString();
 }

   public static String getAttributesForAFile(File fileName) throws IOException {

      if (null==fileName || !(fileName.length()>0) ) {
        System.out.println("fileName is null or the length is not > 0");
        return null;
      }

      if (fileName.isDirectory()) {
          System.out.println("You have sent a Directory name instead send a fileName with path...");
          return null;
      }

      JSONObject fileObj = new JSONObject();
      fileObj.put("AFilePath",fileName.toString());
      fileObj.put("isHideen", fileName.isHidden());
      fileObj.put("lastModified", fileName.lastModified() + " millis");
      fileObj.put("canRead", fileName.canRead());
      fileObj.put("canWrite", fileName.canWrite());
      fileObj.put("canExecute", fileName.canExecute());

      System.out.println(fileObj.toString());

    return (fileObj.toString()); 
   }

    public static void main(String[] args) throws IOException {

       String pathName = "/Users/harry/practice/Java/asgnment/";
       File fileName   = new File("/Users/harry/practice/Java/asgnment/TestNewOne.java");
        
       String S = new TestNewOne().getAllFileDirsListForAPath(pathName);
       System.out.println("--------------------------------");
       System.out.println(S);
       System.out.println("--------------------------------");
       TestNewOne.getAttributesForAFile(fileName);
      
  }
}
